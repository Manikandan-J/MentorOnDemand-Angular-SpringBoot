package com.mentorondemand.repo;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.Comission;

public interface ComissionRepo extends CrudRepository<Comission, Long>{

}
