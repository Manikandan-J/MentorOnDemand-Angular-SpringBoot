package com.mentorondemand.repo;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.Skills;

public interface CourseRepository extends CrudRepository<Skills, Long> {

}
