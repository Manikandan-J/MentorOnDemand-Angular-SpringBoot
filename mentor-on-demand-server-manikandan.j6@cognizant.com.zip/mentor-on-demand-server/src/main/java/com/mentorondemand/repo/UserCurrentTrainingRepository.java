package com.mentorondemand.repo;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.UserCurrentTraining;

public interface UserCurrentTrainingRepository extends CrudRepository<UserCurrentTraining, Long> {
	
	

}
