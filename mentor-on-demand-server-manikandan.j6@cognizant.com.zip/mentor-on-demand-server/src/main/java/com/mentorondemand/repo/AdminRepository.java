package com.mentorondemand.repo;

import org.springframework.data.repository.CrudRepository;

import com.mentorondemand.model.Admin;

public interface AdminRepository extends CrudRepository<Admin, Long> {

	Admin getAdminByEmail(String email);

}
