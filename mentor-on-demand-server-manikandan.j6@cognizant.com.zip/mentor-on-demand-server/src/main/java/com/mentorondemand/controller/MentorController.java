package com.mentorondemand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;

import com.mentorondemand.model.MentorPayment;

import com.mentorondemand.model.Trainings;
import com.mentorondemand.model.User;

import com.mentorondemand.repo.MentorRepository;

import com.mentorondemand.repo.TrainingRepository;
import com.mentorondemand.service.LoginService;
import com.mentorondemand.service.MentorService;

@CrossOrigin(origins = "http://localhost:4321")
@RestController
@RequestMapping("/api")
public class MentorController {
	
	
	@Autowired
	MentorService mentorService;
	
	@Autowired
	LoginService loginService;
	
	

	@Autowired
	MentorRepository mentorRepo;
	


	@Autowired
	TrainingRepository trainingRepo;

	
	
	   @CrossOrigin(origins = "http://localhost:4200")
	 	@PostMapping(value = "/mentor/register")
	 	public void registerMentor(@RequestBody Mentor mentor) {
           
		   
		   Login  login_ = loginService.insertCredentials(mentor);
	 		Mentor _mentor =  mentorService.registerMentor(mentor);
	 	}	
	
		@CrossOrigin(origins = "http://localhost:4200")
		@GetMapping(value = "/mentor/mentorMail/{email}")
		public MentorPayment findByEmail(@PathVariable String email) {

			return mentorService.getMentorByEmail(email);
		}
	
	
//		mainTable
		
		@CrossOrigin(origins = "http://localhost:4200")
		@GetMapping(value = "/mentor/mentorMail/mainTable/{email}")
		public Mentor findByMentorEmail(@PathVariable String email) {

			return mentorService.getMentorDetailsByEmail(email);
		}
	
	
	
	
		  @CrossOrigin(origins = "http://localhost:4200")
			@GetMapping("/mentor/getAllMentors")
			public List<Mentor> getAllMentors() {
				System.out.println("Get all Customers...");

				
				return mentorService.getAllMentors();
			}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//BelowBy Team-------------------------------------------------------------------------------------
//	@PostMapping(value = "/mentor/register")
//	public Mentor postCustomer(@RequestBody Mentor mentor) {
//
//		Mentor mentorInsert = mentorRepo.save(new Mentor(mentor.getFirstName(),mentor.getLastName(),mentor.getEmail(),mentor.getPassword(),mentor.getContactNumber(),mentor.getLinkedinUrl(),mentor.getRegDateTime(),mentor.getRegCode(),mentor.getSkills(),mentor.getCurrentCourse(),mentor.getYearOfExperience(),mentor.getRating(),mentor.getSelfRating(),mentor.getStatus()));
//		return mentorInsert;
//
//	}
//	
//	@PostMapping(value = "/mentor/addSkill")
//	public MentorSkills mentorAddSkill(@RequestBody MentorSkills mentorSkills) {
//
//		MentorSkills mentorSkillInsert = skillRepo.save(new MentorSkills(mentorSkills.getMentorId(),
//				mentorSkills.getSkilId(), mentorSkills.getYearsOfExperience(), mentorSkills.getRegDateTime(),
//				mentorSkills.getTrainingsDelivered(), mentorSkills.getFacilities()));
//		return mentorSkillInsert;
//
//	}
//
//	@PostMapping(value = "/mentor/confirmation")
//	public Trainings mentorconfirmation(@RequestBody ProposalRequest proposalRequest) {
//
//MentorCalendar mentorCalendar=mentorCalendarRepo.findByMentorId(proposalRequest.getMentorId());
//		Trainings trainingsInsert = trainingRepo.save(new Trainings(proposalRequest.getTechnologyId(),proposalRequest.getMentorId(),mentorCalendar.getStartTime(),mentorCalendar.getEndTime()));
//		return trainingsInsert;
//
//	}
//
//	@DeleteMapping("/mentor/rejection/{id}")
//	public ResponseEntity<String> deleteCustomer(@PathVariable("id") long id) {
//		System.out.println("Delete Customer with ID = " + id + "...");
//
//		proposalRequestRepo.deleteById(id);
//
//		return new ResponseEntity<>("Customer has been deleted!", HttpStatus.OK);
//	}
//	
//	@PostMapping(value = "/mentor/addCalendar")
//	public MentorCalendar mentorAddCalendar(@RequestBody MentorCalendar mentorCalendar) {
//
//		MentorCalendar mentorCalendarInsert = calendarRepo.save(new MentorCalendar(mentorCalendar.getMentorId(),mentorCalendar.getStartTime(),mentorCalendar.getEndTime()));
//		return mentorCalendarInsert;
//
//	}
}
