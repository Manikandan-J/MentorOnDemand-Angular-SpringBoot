package com.mentorondemand.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;

import com.mentorondemand.model.MentorPayment;

import com.mentorondemand.model.Skills;
import com.mentorondemand.model.User;
import com.mentorondemand.model.UserCurrentTraining;
import com.mentorondemand.model.UserPayment;

import com.mentorondemand.repo.SkillRepository;
import com.mentorondemand.repo.UserRepository;
import com.mentorondemand.service.AdminService;
import com.mentorondemand.service.LoginService;
import com.mentorondemand.service.UserService;

@CrossOrigin(origins = "http://localhost:4321")
@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserRepository userRepo;

	@Autowired
	SkillRepository skillRepo;


	@Autowired
	UserService userService;
   
	@Autowired
	LoginService loginService;
	@Autowired
	AdminService adminservice;
	 
	   @CrossOrigin(origins = "http://localhost:4200")
	 	@PostMapping(value = "/user/register")
	 	public void registerUser(@RequestBody User user) {
  
	 		Login  login_ = loginService.insertCredentials(user);
	 		User user_=  userService.registerUser(user);
	 
	 	}
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/user/getAllUsers")
	public List<User> getAllUsers() {
		System.out.println("Get all Customers...");

		
		return userService.getAllUsers();
	}
	
//	@CrossOrigin(origins = "http://localhost:4200")
//	@GetMapping("/user/usersSarch/{name}/{start_time}")
//	public List<MentorCalender> userSearch(@PathVariable ("name") String name,@PathVariable ("start_time") String start_time) {
//		
//
//		
////		return userService.userSearch(name,start_time);
//	}
//	
	
	

	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/user/getCurrentTrainings")
	public List<UserCurrentTraining> getCurrentTraining() {
		System.out.println("Get all Customers...");

		
		return userService.getCurrentTrainings();
	}
	
    @CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "user/email/{email}")
	public User getUserByEmail(@PathVariable String email) {

		return userService.getUserByEmail(email);
	}
    
    @CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "/user/getTrainingById/{trainingId}")
	public Optional<UserCurrentTraining> findByEmail(@PathVariable long trainingId) {

		return userService.getTraining(trainingId);
	}
    
    @CrossOrigin(origins = "http://localhost:4200")
 	@PostMapping(value = "/user/makePay")
 	public void makeUserPayment(@RequestBody UserPayment userPay) {

 		UserPayment _userPayment = userService.makeUserPay(userPay);
 
 	}
    
    
      
	
	
	
	
	
	
	
	
	
	
	
    
    
    
    
    
    
    
    
    


}
