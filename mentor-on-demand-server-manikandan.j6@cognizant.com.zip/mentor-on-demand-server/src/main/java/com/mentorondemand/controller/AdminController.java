package com.mentorondemand.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Comission;
import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;

import com.mentorondemand.model.MentorPayment;


import com.mentorondemand.model.Skills;
import com.mentorondemand.model.User;
import com.mentorondemand.repo.AdminRepository;

import com.mentorondemand.repo.LoginRepository;
import com.mentorondemand.repo.MentorRepository;


import com.mentorondemand.repo.SkillRepository;
import com.mentorondemand.repo.UserRepository;
import com.mentorondemand.service.AdminService;
import com.mentorondemand.service.LoginService;
import com.mentorondemand.service.MentorService;

import com.mentorondemand.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AdminController {
	
     
     
     
     
     @Autowired
     AdminService adminService;
     @Autowired 
     LoginService loginService;
//     @Autowired
//     TrainingService trainingService;
     @Autowired
     UserService userService;
     
     @Autowired
     MentorService mentorService;
     
     
    @CrossOrigin(origins = "http://localhost:4200")
 	@PostMapping(value = "/admin/register")
 	public void registerAdmin(@RequestBody Admin admin) {

    	Login  login_ = loginService.insertCredentials(admin);
 		Admin admin_ =  adminService.registerAdmin(admin);
 	}
    
//    @CrossOrigin(origins = "http://localhost:4200")
//  	@PostMapping(value = "/admin/createTraining")
//  	public void createTraining(@RequestBody MentorCalender training) {
//
//     	
//  		MentorCalender training_ = trainingService.createTraining(training);
//  	}
    
    @CrossOrigin(origins = "http://localhost:4200")
	@GetMapping(value = "admin/email/{email}")
	public Admin getAdminByEmail(@PathVariable String email) {

		return adminService.getAdminByEmail(email);
	}
    
    
    
    
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/admin/{id}")
    public ResponseEntity<MentorPayment> updateMentorPayment(@PathVariable("id")long id, @RequestBody MentorPayment mentorPayment)
    {
    	return this.adminService.updateMentorPayment(id,mentorPayment);
    }
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PutMapping("/admin/UpdateCommisison/{id}")
    public ResponseEntity<Comission> updateCommission(@PathVariable("id")long id, @RequestBody long commision)
    {
    	return this.adminService.updateCommisson(id,commision);
    }
    
    
    @CrossOrigin(origins = "http://localhost:4200")
   	@GetMapping("/admin/getAllUser")
   	public List<User> getAllUser() {
   		System.out.println("Get all Customers...");

   		
   		return userService.getAllUser();
   	}

   
    
    @CrossOrigin(origins = "http://localhost:4200")
   	@GetMapping("/admin/getAllMentor")
   	public List<Mentor> getAllMentor() {
   		System.out.println("Get all Customers...");

   		
   		return mentorService.getAllMentors();
   	}

    
   @CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping(value = "/admin/{email}")
 
	public ResponseEntity<String> deleteCustomer(@PathVariable("email") String email) {
		System.out.println("Delete Mentor with Email = " + email + "...");
      
		
		return this.adminService.deleteMentorByEmail(email);
		
	}
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
		
}