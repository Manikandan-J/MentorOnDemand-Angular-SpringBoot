package com.mentorondemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="commision")
public class Comission {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column
	private long commision;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getCommision() {
		return commision;
	}
	public void setCommision(long commision) {
		this.commision = commision;
	}
	public Comission(long commision) {
		super();
		this.commision = commision;
	}
	public Comission() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Comission [id=" + id + ", commision=" + commision + "]";
	}
	

}
