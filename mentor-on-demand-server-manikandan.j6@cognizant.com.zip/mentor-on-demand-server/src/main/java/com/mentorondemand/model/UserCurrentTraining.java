package com.mentorondemand.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_current_training")
public class UserCurrentTraining {

	@Column(name= "training_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name="user_mail_id")
	private String userMailId;
	@Column(name="mentor_mail_id")
	private String mentorMailId;
	@Column(name="course_name")
	private String courseName;
	@Column(name="end_time")
	private String endTime;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserMailId() {
		return userMailId;
	}
	public void setUserMailId(String userMailId) {
		this.userMailId = userMailId;
	}
	public String getMentorMailId() {
		return mentorMailId;
	}
	public void setMentorMailId(String mentorMailId) {
		this.mentorMailId = mentorMailId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public UserCurrentTraining(long id, String userMailId, String mentorMailId, String courseName, String endTime) {
		super();
		this.id = id;
		this.userMailId = userMailId;
		this.mentorMailId = mentorMailId;
		this.courseName = courseName;
		this.endTime = endTime;
	}
	public UserCurrentTraining(String userMailId, String mentorMailId, String courseName, String endTime) {
		super();
		this.userMailId = userMailId;
		this.mentorMailId = mentorMailId;
		this.courseName = courseName;
		this.endTime = endTime;
	}
	@Override
	public String toString() {
		return "UserCurrentTraining [id=" + id + ", userMailId=" + userMailId + ", mentorMailId=" + mentorMailId
				+ ", courseName=" + courseName + ", endTime=" + endTime + "]";
	}
	public UserCurrentTraining() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	
	
}
