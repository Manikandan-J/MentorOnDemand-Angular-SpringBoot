package com.mentorondemand.service;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;
import com.mentorondemand.model.User;
import com.mentorondemand.repo.LoginRepository;

@Service
public class LoginService {
	
	@Autowired
	private LoginRepository loginRepo;

	public List<Login> getAllCredentials() {
		// TODO Auto-generated method stub
		List<Login> credentials = new ArrayList<>();
		loginRepo.findAll().forEach(credentials::add);

		return credentials;
	}

	public Login enterCredentials(Login loginCredentials) {
		Login _login = loginRepo.save(new Login(loginCredentials.getEmail(),loginCredentials.getPassword(),loginCredentials.getRole()));
		return _login;
	}

	public Login insertCredentials(User user) {
		
		Login _login = loginRepo.save(new Login(user.getEmail(),user.getPassword(),user.getRole()));
		return _login;
	}

	public Login insertCredentials(Mentor mentor) {
		Login _login = loginRepo.save(new Login(mentor.getEmail(),mentor.getPassword(),"mentor"));
		return _login;
	}

	public Login insertCredentials(Admin admin) {
		Login _login = loginRepo.save(new Login(admin.getEmail(),admin.getPassword(),"admin"));
		return _login;
	}

	

}
