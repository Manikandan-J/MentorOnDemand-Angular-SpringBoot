package com.mentorondemand.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;
import com.mentorondemand.model.MentorPayment;
import com.mentorondemand.model.User;
import com.mentorondemand.repo.MentorPaymentRepository;
import com.mentorondemand.repo.MentorRepository;

@Service
public class MentorService {
	
	
	@Autowired
	MentorRepository mentorRepo;
	
	@Autowired
	MentorPaymentRepository mentorPaymentRepo;

	public Mentor registerMentor(Mentor mentor) {
		Mentor _mentor = mentorRepo.save(new Mentor(mentor.getName(),mentor.getEmail(),mentor.getPassword(),mentor.getAddress(),mentor.getLinkedinUrl(),mentor.getSlotTime(),mentor.getTechnology(),mentor.getExperience(),mentor.getContactNumber(),mentor.getRegDateTime(),mentor.getStatus()));
		return _mentor;
	}

	public MentorPayment getMentorByEmail(String email) {
		
		
		MentorPayment _mentorPayment = mentorPaymentRepo.findByEmail(email);
		return _mentorPayment;
	}

	public Mentor getMentorDetailsByEmail(String email) {
		// TODO Auto-generated method stub
	   
		Mentor _mentor = mentorRepo.findByEmail(email);
		return _mentor;
		
		
		
	}

	public List<Mentor> getAllMentors() {
		
		List<Mentor> mentorList = new ArrayList<>();
		mentorRepo.findAll().forEach(mentorList::add);

		return mentorList;
	}

	
	

}
