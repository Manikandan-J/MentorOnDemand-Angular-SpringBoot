package com.mentorondemand.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Comission;
import com.mentorondemand.model.MentorPayment;
import com.mentorondemand.repo.AdminRepository;
import com.mentorondemand.repo.ComissionRepo;
import com.mentorondemand.repo.MentorPaymentRepository;
import com.mentorondemand.repo.MentorRepository;

@Service
public class AdminService {
	
	@Autowired
	AdminRepository adminRepo;
	@Autowired
	MentorPaymentRepository mentorPaymentRepo;
	@Autowired
	MentorRepository mentorRepo;
	@Autowired
	ComissionRepo commissionRepo;

	public Admin registerAdmin(Admin admin) {
		Admin _admin = adminRepo.save(new Admin(admin.getName(),admin.getGender(),admin.getEmail(),admin.getPassword(),admin.getAddress(),admin.getContactNumber(),admin.getRole()));
		return _admin;
	}

	public Admin getAdminByEmail(String email) {
	    Admin admin = adminRepo.getAdminByEmail(email);
		return admin;
	}

	public ResponseEntity<MentorPayment> updateMentorPayment(long id, MentorPayment mentorPayment) {
		// TODO Auto-generated method stub
		Optional<MentorPayment> mentorPaymentData = mentorPaymentRepo.findById(id);
		
		if(mentorPaymentData.isPresent())
		{
			MentorPayment _mentorPayment = mentorPaymentData.get();
			_mentorPayment.setEmail(mentorPayment.getEmail());
			_mentorPayment.setCourseName(mentorPayment.getCourseName());
			_mentorPayment.setSlot1(mentorPayment.getSlot1());
			_mentorPayment.setSlot2(mentorPayment.getSlot2());
			_mentorPayment.setSlot3(mentorPayment.getSlot3());
			_mentorPayment.setSlot4(mentorPayment.getSlot4());
			_mentorPayment.setSlot4(mentorPayment.getTotalFee());
			return new ResponseEntity<>(mentorPaymentRepo.save(_mentorPayment),HttpStatus.OK);
			
					
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}

	public ResponseEntity<String> deleteMentorByEmail(String email) {
		// TODO Auto-generated method stub
		mentorRepo.deleteByEmail(email);
		return new ResponseEntity<>("Customer has been deleted !",HttpStatus.OK);
	}


	public ResponseEntity<Comission> updateCommisson(long id, long commision) {
		
		Optional<Comission> obj = commissionRepo.findById(id);
		if(obj.isPresent())
		{
			Comission _commission = obj.get();
			_commission.setCommision(commision);
			
			return new ResponseEntity<>(commissionRepo.save(_commission),HttpStatus.OK);
			
					
		}
		else
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
	}





}
