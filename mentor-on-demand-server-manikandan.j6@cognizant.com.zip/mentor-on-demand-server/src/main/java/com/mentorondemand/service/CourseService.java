package com.mentorondemand.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.model.Skills;
import com.mentorondemand.repo.CourseRepository;


@Service
public class CourseService {

	@Autowired
	private CourseRepository courseRepo;
	
	
	
	public List<Skills> getAllCourses() {
		// TODO Auto-generated method stub
		List<Skills> course = new ArrayList<>();
		 courseRepo.findAll().forEach(course::add);

		return course;
	}

}
