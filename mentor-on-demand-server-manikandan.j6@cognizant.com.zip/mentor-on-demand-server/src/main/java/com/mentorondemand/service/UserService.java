package com.mentorondemand.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mentorondemand.model.Admin;
import com.mentorondemand.model.Login;
import com.mentorondemand.model.Mentor;

import com.mentorondemand.model.User;
import com.mentorondemand.model.UserCurrentTraining;
import com.mentorondemand.model.UserPayment;

import com.mentorondemand.repo.UserCurrentTrainingRepository;
import com.mentorondemand.repo.UserPaymentRepository;
import com.mentorondemand.repo.UserRepository;

@Service
public class UserService {
	
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	UserCurrentTrainingRepository userCurrentTrainingRepo;
	
	@Autowired
	UserPaymentRepository userPaymentRepo;
	
//	@Autowired
//	CreateTrainingRepo createTrainingRepo;

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		
		
		List<User> userList = new ArrayList<>();
		userRepo.findAll().forEach(userList::add);

		return userList;
	}

	public List<UserCurrentTraining> getCurrentTrainings() {
		
		List<UserCurrentTraining> trainingList = new ArrayList<>();
		userCurrentTrainingRepo.findAll().forEach(trainingList::add);

		return trainingList;
		
	}

	public User registerUser(User user) {
		
		User _user = userRepo.save(new User(user.getName(),user.getGender(),user.getEmail(),user.getPassword(),user.getAddress(),user.getContactNumber(),user.getRole()));
    	return _user;
		
	}

	public User getUserByEmail(String email) {
		 User user = userRepo.getUserByEmail(email);
			return user;
	}

	public Optional<UserCurrentTraining> getTraining(long trainingId) {
		
		Optional<UserCurrentTraining> _userCurrentTraining = userCurrentTrainingRepo.findById(trainingId);

		return _userCurrentTraining;
		
	}

	public UserPayment makeUserPay(UserPayment userPay) {
		
		UserPayment _userPay = userPaymentRepo.save(new UserPayment(userPay.getTrainingId(),userPay.getMentorMailId(),userPay.getCourseName(),userPay.getAmount()));
		return _userPay;
	}

//	public List<MentorCalender> userSearch(String name, String start_time) {
//		List<MentorCalender> _search=new ArrayList<MentorCalender>();
//		createTrainingRepo.search(name,start_time).forEach(_search::add);
//
//return _search;
//	}

	public List<User> getAllUser() {
		
		List<User> userList = new ArrayList<>();
		userRepo.findAll().forEach(userList::add);

		return userList;
		
	}
	
	
	
}
