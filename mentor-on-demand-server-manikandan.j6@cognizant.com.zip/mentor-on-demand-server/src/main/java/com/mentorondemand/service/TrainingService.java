//package com.mentorondemand.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.mentorondemand.model.MentorCalender;
//import com.mentorondemand.repo.CreateTrainingRepo;
//
//@Service
//public class TrainingService {
//
//	
//	@Autowired
//	CreateTrainingRepo repoObj;
//	
//	public MentorCalender createTraining(MentorCalender training) {
//		
//		
//		MentorCalender create = repoObj.save(new MentorCalender(training.getStartDate(),training.getStartDate(),training.getEndDate(),training.getCourseName(),training.getCourseFee()));
//	
//	    return create;
//	}
//
//}
